   
    <div class="loader-wrapper" id="loader2">
      <span class="loader"><span class="loader-inner"></span></span>
    </div>

    <script>
        window.onload=function() {
            document.getElementById('loader2').style.display="none";
            document.getElementById('load').style.display="block";
        }
    </script>

    
<?php include("assets/scripts.php"); ?>